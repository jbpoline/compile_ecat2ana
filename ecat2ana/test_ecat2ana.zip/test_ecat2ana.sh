#!/bin/sh
if [ $OS = "Windows_NT" ]; then
EXT=.exe;
else
EXT=;
fi
PROGRAM=../ecat2ana$EXT;
echo ""
echo ===============================================================================
echo "testing "$PROGRAM" (in MSYS)"
echo ===============================================================================
echo ""
if [ -f image2.i ]; then
echo "Test data seems to exist, thus not created now."
else 
echo ===============================================================================
echo "creating test data"
echo ===============================================================================
echo ""

asc2flo image1.dat image1.bin
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
flo2ecat -t=Adv -f=image1.inf image1.bin image1.v
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
eframe image1.v image1.fra
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
edecay -i=C-11 image1.v
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
esetstrt image1.v 2007-03-20 15:22:02
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
ecat2tif -rb image1.v image1.tif
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
e7to63 image1.v image1.img
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi

asc2flo image2.dat image2.bin
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
flo2ecat -t=HR+ -f=image2.inf image2.bin image2.v
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
eframe image2.v image2.fra
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
edecay -i=F-18 image2.v
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
esetstrt image2.v 2006-06-20 12:01:59
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
ecat2tif -rb image2.v image2.tif
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
e7to63 image2.v image2.img
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi

flo2ecat -t=HR+ -f=image2.inf image2.bin image2.i
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
eframe image2.i image2.fra
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
edecay -i=F-18 image2.i
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
esetstrt image2.i 2006-06-20 12:01:59

fi
echo ===============================================================================
echo ""
echo ===============================================================================
echo "1.1.1: No command line options or arguments. Error with user info."
if [ -f stdout.txt ] ; then rm stdout.txt ; fi
$PROGRAM > stdout.txt
if [ $? -eq 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.
iftisval_1_0_4 stdout.txt "See also"
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
iftisval_1_0_4 stdout.txt "Keywords"
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""
echo ===============================================================================
echo "1.1.2: Unknown option."
if [ -f stderr.txt ] ; then rm stderr.txt ; fi
$PROGRAM -stupidoption image1.v 2> stderr.txt
if [ $? -eq 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.
iftisval_1_0_4 stderr.txt Error "invalid option '-stupidoption'"
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""
echo ===============================================================================
echo "1.1.3: Extra argument."
echo "       NOT APPLICABLE"
echo ===============================================================================
echo ""
echo ===============================================================================
echo "1.2.1: option -h print user info"
if [ -f stdout.txt ] ; then rm stdout.txt ; fi
$PROGRAM -h > stdout.txt
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.
iftisval_1_0_4 stdout.txt "See also"
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
iftisval_1_0_4 stdout.txt "Keywords"
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""
echo ===============================================================================
echo "1.2.2: option --help print user info"
if [ -f stdout.txt ] ; then rm stdout.txt ; fi
$PROGRAM --help > stdout.txt
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.
iftisval_1_0_4 stdout.txt "See also"
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
iftisval_1_0_4 stdout.txt "Keywords"
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""
echo ===============================================================================
echo "1.3.1: option --build prints software version info"
if [ -f test.dat ] ; then rm test.dat ; fi
echo 0.5 4.0 > test.dat
echo # Correct nr of lines containing Build >> test.dat
if [ -f stdout.txt ] ; then rm stdout.txt ; fi
$PROGRAM --build | grep -c Build > stdout.txt
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.
addtimes stdout.txt
echo # Nr of lines containing Build >> stdout.txt
dftmatch stdout.txt test.dat
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""
echo ===============================================================================
echo "1.4.1: option --silent"
if [ -f stdout.txt ] ; then rm stdout.txt ; fi
$PROGRAM -test --silent image1.v > stdout.txt
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.
iftisval_1_0_4 stdout.txt SILENT "1"
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""
iftisval_1_0_4 stdout.txt VERBOSE "0"
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""
echo ===============================================================================
echo "1.4.2: option --verbose"
if [ -f stdout.txt ] ; then rm stdout.txt ; fi
$PROGRAM -test --verbose image1.v > stdout.txt
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.
iftisval_1_0_4 stdout.txt VERBOSE "1"
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""
iftisval_1_0_4 stdout.txt SILENT "0"
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""
echo ===============================================================================
echo ""
echo ===============================================================================
echo "1.5.1: option -little; without it"
if [ -f stdout.txt ] ; then rm stdout.txt ; fi
$PROGRAM -test image1.v > stdout.txt
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.
iftisval_1_0_4 stdout.txt ana_order "1"
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""
echo ===============================================================================
echo "1.5.2: option -little; with it"
if [ -f stdout.txt ] ; then rm stdout.txt ; fi
$PROGRAM -test -L image1.v > stdout.txt
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.
iftisval_1_0_4 stdout.txt ana_order "0"
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""

if [ -f stdout.txt ] ; then rm stdout.txt ; fi
$PROGRAM -test -Little image1.v > stdout.txt
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.
iftisval_1_0_4 stdout.txt ana_order "0"
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""

if [ -f stdout.txt ] ; then rm stdout.txt ; fi
$PROGRAM -test -l image1.v > stdout.txt
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.
iftisval_1_0_4 stdout.txt ana_order "0"
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""

if [ -f stdout.txt ] ; then rm stdout.txt ; fi
$PROGRAM -test -little image1.v > stdout.txt
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.
iftisval_1_0_4 stdout.txt ana_order "0"
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""

if [ -f stdout.txt ] ; then rm stdout.txt ; fi
$PROGRAM -test -pc image1.v > stdout.txt
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.
iftisval_1_0_4 stdout.txt ana_order "0"
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""

if [ -f stdout.txt ] ; then rm stdout.txt ; fi
$PROGRAM -test -i image1.v > stdout.txt
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.
iftisval_1_0_4 stdout.txt ana_order "0"
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""
echo ===============================================================================
echo ""
echo ===============================================================================
echo "1.6.1: option -big; without it"
echo "       tested already in 1.5.1"
echo ===============================================================================
echo "1.6.2: option -big; with it"
if [ -f stdout.txt ] ; then rm stdout.txt ; fi
$PROGRAM -test -B image1.v > stdout.txt
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.
iftisval_1_0_4 stdout.txt ana_order "1"
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""

if [ -f stdout.txt ] ; then rm stdout.txt ; fi
$PROGRAM -test -Big image1.v > stdout.txt
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.
iftisval_1_0_4 stdout.txt ana_order "1"
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""

if [ -f stdout.txt ] ; then rm stdout.txt ; fi
$PROGRAM -test -b image1.v > stdout.txt
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.
iftisval_1_0_4 stdout.txt ana_order "1"
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""

if [ -f stdout.txt ] ; then rm stdout.txt ; fi
$PROGRAM -test -big image1.v > stdout.txt
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.
iftisval_1_0_4 stdout.txt ana_order "1"
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""

if [ -f stdout.txt ] ; then rm stdout.txt ; fi
$PROGRAM -test -sun image1.v > stdout.txt
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.
iftisval_1_0_4 stdout.txt ana_order "1"
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""

if [ -f stdout.txt ] ; then rm stdout.txt ; fi
$PROGRAM -test -sparc image1.v > stdout.txt
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.
iftisval_1_0_4 stdout.txt ana_order "1"
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""
echo ===============================================================================
echo ""
echo ===============================================================================
echo "1.7.1: option -o; without it"
if [ -f stdout.txt ] ; then rm stdout.txt ; fi
$PROGRAM -test image1.v > stdout.txt
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.
iftisval_1_0_4 stdout.txt outputdir ""
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""
echo ===============================================================================
echo "1.7.2: option -o; with it"
if [ -f stdout.txt ] ; then rm stdout.txt ; fi
$PROGRAM -test -o=newdir image1.v > stdout.txt
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.
iftisval_1_0_4 stdout.txt outputdir "newdir"
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""
echo ===============================================================================
echo "1.7.3: option -o="
if [ -f temp.v ] ; then rm temp.v ; fi
cp image1.v temp.v
if [ -f temp.hdr ] ; then rm temp.hdr ; fi
if [ -f temp.img ] ; then rm temp.img ; fi
if [ -f stdout.txt ] ; then rm stdout.txt ; fi
$PROGRAM -test -o= temp.v > stdout.txt
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.
iftisval_1_0_4 stdout.txt outputdir "."
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""
if [ -f temp.hdr ] ; then rm temp.hdr; else echo Failed!; exit 1 ; fi
if [ -f temp.img ] ; then rm temp.img; else echo Failed!; exit 1 ; fi
echo passed. ; echo ""
echo ===============================================================================
echo "1.7.4: Check that original ECAT file is not overwritten by Analyze data"
if [ -f stdout.txt ] ; then rm stdout.txt ; fi
if [ -f stderr.txt ] ; then rm stderr.txt ; fi
if [ -f temp.img ] ; then rm temp.img ; fi
if [ -f temp.hdr ] ; then rm temp.hdr ; fi
if [ -f temp2.v ] ; then rm temp2.v ; fi
if [ -f temp2.img ] ; then rm temp2.img ; fi
if [ -f temp2.hdr ] ; then rm temp2.hdr ; fi
cp image1.img temp.img
cp image1.v temp2.v
$PROGRAM -test -o= temp.img temp2.v > stdout.txt 2> stderr.txt
if [ $? -eq 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.
iftisval_1_0_4 stderr.txt Error ".\temp.img would be overwritten."
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""
echo "check that next file was still processed ok"
if [ -f temp2.hdr ] ; then rm temp2.hdr; else echo Failed!; exit 1 ; fi
if [ -f temp2.img ] ; then rm temp2.img; else echo Failed!; exit 1 ; fi
echo passed. ; echo ""
echo ===============================================================================
echo "1.7.5: Output path and Analyze files exist: overwritten"
if [ -f temp.img ] ; then rm temp.img ; fi
if [ -f temp.v ] ; then rm temp.v ; fi
cp image1.img temp.img
cp image2.v temp.v
rm temp/* temp2/* 2> nul
rmdir temp temp2 2> nul
echo passed. ; echo ""

$PROGRAM -o=temp -sif temp.img
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""
# cti2sif temp.img temp/temp.sif
# cif [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
# echo passed. ; echo ""
ana2ecat -6 temp/temp temp2
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""
imgmatch -roughly image1.img temp2/temp.img
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""

$PROGRAM -o=temp -sif temp.v
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""
# cti2sif temp.v temp/temp.sif
# if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
# echo passed. ; echo ""
ana2ecat -7 temp/temp temp2
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""
imgmatch -roughly image2.v temp2/temp.v
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""
echo ===============================================================================
echo ""
echo ===============================================================================
echo "1.8.1: Z flipping: no option or environment variable"
ANALYZE_FLIP=;
export ANALYZE_FLIP
echo "ANALYZE_FLIP = "$ANALYZE_FLIP;
if [ -f stdout.txt ] ; then rm stdout.txt ; fi
$PROGRAM -test image1.v > stdout.txt
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.
iftisval_1_0_4 stdout.txt flipping "1"
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""
echo ===============================================================================
echo "1.8.2: Z flipping: environment variable ANALYZE_FLIP=y"
ANALYZE_FLIP=y;
export ANALYZE_FLIP
echo "ANALYZE_FLIP = "$ANALYZE_FLIP;
if [ -f stdout.txt ] ; then rm stdout.txt ; fi
$PROGRAM -test image1.v > stdout.txt
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.
iftisval_1_0_4 stdout.txt flipping "1"
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""
echo ===============================================================================
echo "1.8.3: Z flipping: environment variable ANALYZE_FLIP=n"
ANALYZE_FLIP=n;
export ANALYZE_FLIP
echo "ANALYZE_FLIP = "$ANALYZE_FLIP;
if [ -f stdout.txt ] ; then rm stdout.txt ; fi
$PROGRAM -test image1.v > stdout.txt
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.
iftisval_1_0_4 stdout.txt flipping "0"
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""
echo ===============================================================================
echo "1.8.4: Z flipping: -flip=y, independent on environment variable"
ANALYZE_FLIP=n;
export ANALYZE_FLIP
echo "ANALYZE_FLIP = "$ANALYZE_FLIP;
if [ -f stdout.txt ] ; then rm stdout.txt ; fi
$PROGRAM -test -flip=y image1.v > stdout.txt
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.
iftisval_1_0_4 stdout.txt flipping "1"
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""
echo ===============================================================================
echo "1.8.5: Z flipping: -flip=n, independent on environment variable"
ANALYZE_FLIP=y;
export ANALYZE_FLIP
echo "ANALYZE_FLIP = "$ANALYZE_FLIP;
if [ -f stdout.txt ] ; then rm stdout.txt ; fi
$PROGRAM -test -flip=n image1.v > stdout.txt
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.
iftisval_1_0_4 stdout.txt flipping "0"
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""
ANALYZE_FLIP=;
export ANALYZE_FLIP
echo "ANALYZE_FLIP = "$ANALYZE_FLIP;
echo ===============================================================================
echo ""
echo ===============================================================================
echo "1.9.1: Option -frames: without it"
if [ -f stdout.txt ] ; then rm stdout.txt ; fi
$PROGRAM -test image1.v > stdout.txt
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.
iftisval_1_0_4 stdout.txt separate_frames "0"
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""
echo ===============================================================================
echo "1.9.2: Option -frames: with it"
if [ -f stdout.txt ] ; then rm stdout.txt ; fi
rm frames/* 2> nul
rmdir frames 2> nul
$PROGRAM -test -frames -o=frames image2.v > stdout.txt
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.
iftisval_1_0_4 stdout.txt separate_frames "1"
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""
if [ -f frames/image2_fr001.hdr ]; then rm frames/image2_fr001.hdr ; else echo Failed!; exit 1; fi
if [ -f frames/image2_fr001.img ]; then rm frames/image2_fr001.img ; else echo Failed!; exit 1; fi
if [ -f frames/image2_fr002.hdr ]; then rm frames/image2_fr002.hdr ; else echo Failed!; exit 1; fi
if [ -f frames/image2_fr002.img ]; then rm frames/image2_fr002.img ; else echo Failed!; exit 1; fi
echo passed. ; echo ""
echo ===============================================================================
echo ""
echo ===============================================================================
echo "2.1.1: Input file name not given"
if [ -f stderr.txt ] ; then rm stderr.txt ; fi
$PROGRAM -test -frames -o=frames 2> stderr.txt
if [ $? -eq 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.
iftisval_1_0_4 stderr.txt Error "no ECAT files were specified."
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""
echo ===============================================================================
echo "2.2.1: non-existing input file"
if [ -f stderr.txt ] ; then rm stderr.txt ; fi
$PROGRAM -test nonexisting.v 2> stderr.txt
if [ $? -eq 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.
iftisval_1_0_4 stderr.txt Error "file nonexisting.v does not exist"
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""
echo ===============================================================================
echo "2.3.1: format not ECAT image"
if [ -f stderr.txt ] ; then rm stderr.txt ; fi
$PROGRAM -test image1.bin 2> stderr.txt
if [ $? -eq 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.;
iftisval_1_0_4 stderr.txt Error "unknown file format"
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.; echo ""

if [ -f stderr.txt ] ; then rm stderr.txt ; fi
$PROGRAM -test image1.dat 2> stderr.txt
if [ $? -eq 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.;
iftisval_1_0_4 stderr.txt Error "unknown file format"
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.; echo ""
echo ===============================================================================
echo "2.3.2: ECAT 7 3D: ok"
rm temp/* temp2/* 2> nul
rmdir temp temp2 2> nul
$PROGRAM -test -o=temp -sif image2.v 2> stderr.txt
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.;
# cti2sif image2.v temp/image2.sif
# if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
# echo passed.;
ana2ecat -7 temp/image2 temp2
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""
imgmatch -roughly image2.v temp2/image2.v
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""
echo ===============================================================================
echo "2.3.3: ECAT 7 2D: ok"
if [ -f stderr.txt ] ; then rm stderr.txt ; fi
rm temp/* temp2/* 2> nul
rmdir temp temp2 2> nul
$PROGRAM -test -o=temp -sif image2.i 2> stderr.txt
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.;
# cti2sif image2.v temp/image2.sif
# if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
# echo passed.;
ana2ecat -7 temp/image2 temp2
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""
imgmatch -roughly image2.i temp2/image2.v
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""
echo ===============================================================================
echo "2.3.4: ECAT 6.3: ok"
if [ -f stderr.txt ] ; then rm stderr.txt ; fi
rm temp/* temp2/* 2> nul
rmdir temp temp2 2> nul
$PROGRAM -test -o=temp -sif image2.img 2> stderr.txt
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.;
#cti2sif image2.img temp/image2.sif
#if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
#echo passed.;
ana2ecat -6 temp/image2 temp2
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""
imgmatch -roughly image2.img temp2/image2.img
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""
echo ===============================================================================
echo "2.4.1: ECAT file contains discontinuous frame or plane numbers"
if [ -f stderr.txt ] ; then rm stderr.txt ; fi
if [ -f temp.img ] ; then rm temp.img ; fi
rm temp/* temp2/* 2> nul
rmdir temp temp2 2> nul
esplit image2.img 2 3-4 temp.img
$PROGRAM -test -o=temp -sif temp.img 2> stderr.txt
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.;
#cti2sif temp.img temp/temp.sif
#if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
#echo passed.;
ana2ecat -6 temp/temp temp2
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""
imgmatch -frames=n -planes=n -roughly temp.img temp2/temp.img
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""
echo ===============================================================================
echo "2.5.1: More than one ECAT files as command-line arguments"
if [ -f stderr.txt ] ; then rm stderr.txt ; fi
rm temp/* temp2/* 2> nul
rmdir temp temp2 2> nul
$PROGRAM -test -o=temp image1.v image2.v 2> stderr.txt
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.;
if [ -f temp/image1.hdr ] ; then rm temp/image1.hdr; else echo Failed!; exit 1 ; fi
if [ -f temp/image1.img ] ; then rm temp/image1.img; else echo Failed!; exit 1 ; fi
if [ -f temp/image2.hdr ] ; then rm temp/image2.hdr; else echo Failed!; exit 1 ; fi
if [ -f temp/image2.img ] ; then rm temp/image2.img; else echo Failed!; exit 1 ; fi
echo passed. ; echo ""
echo ===============================================================================
echo "2.5.2: More than one ECAT files given with wildcards"
if [ -f stderr.txt ] ; then rm stderr.txt ; fi
rm temp/* temp2/* 2> nul
rmdir temp temp2 2> nul
$PROGRAM -test -o=temp image?.v 2> stderr.txt
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.;
if [ -f temp/image1.hdr ] ; then rm temp/image1.hdr; else echo Failed!; exit 1 ; fi
if [ -f temp/image1.img ] ; then rm temp/image1.img; else echo Failed!; exit 1 ; fi
if [ -f temp/image2.hdr ] ; then rm temp/image2.hdr; else echo Failed!; exit 1 ; fi
if [ -f temp/image2.img ] ; then rm temp/image2.img; else echo Failed!; exit 1 ; fi
echo passed. ; echo ""
echo ===============================================================================
echo "2.5.3: More than one ECAT files, one leads to error, others ok"
if [ -f stderr.txt ] ; then rm stderr.txt ; fi
rm temp/* temp2/* 2> nul
rmdir temp temp2 2> nul
if [ -f temp.v ] ; then rm temp.v ; fi
cp image2.bin temp.v
$PROGRAM -test -o=temp image1.v temp.v image2.v 2> stderr.txt
if [ $? -eq 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.;
iftisval_1_0_4 stderr.txt Error "unknown file format"
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.; echo ""
if [ -f temp/image1.hdr ] ; then rm temp/image1.hdr; else echo Failed!; exit 1 ; fi
if [ -f temp/image1.img ] ; then rm temp/image1.img; else echo Failed!; exit 1 ; fi
if [ -f temp/image2.hdr ] ; then rm temp/image2.hdr; else echo Failed!; exit 1 ; fi
if [ -f temp/image2.img ] ; then rm temp/image2.img; else echo Failed!; exit 1 ; fi
echo passed. ; echo ""
echo ===============================================================================
echo ""
echo ===============================================================================
echo "3.1.1: Validation of image flipping"
rm temp/* 2> nul
rmdir temp 2> nul
$PROGRAM -o=temp -flip=y -sif image2.v
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.;
#cti2sif image2.v temp/image2.sif
#if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
#echo passed.;
ana2ecat -flip=n -7 temp/image2 temp
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.;
ecatflip_1_3_1 -z temp/image2.v temp/temp2.v
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.;
imgmatch -roughly image2.v temp/temp2.v
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""
rm temp/* 2> nul
rmdir temp 2> nul
$PROGRAM -o=temp -flip=n -sif image2.v
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.;
#cti2sif image2.v temp/image2.sif
#if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
#echo passed.;
ana2ecat -flip=y -7 temp/image2 temp
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.;
ecatflip_1_3_1 -z temp/image2.v temp/temp2.v
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.;
imgmatch -roughly image2.v temp/temp2.v
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""
echo ===============================================================================
echo "3.2.1: Byte order is set correctly"
rm temp/* 2> nul
rmdir temp 2> nul
$PROGRAM -o=temp -little -sif image2.v
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.;
#cti2sif image2.v temp/image2.sif
#if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
#echo passed.;
anabyteo -B temp/image2
ana2ecat -7 temp/image2 temp
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.;
imgmatch -roughly image2.v temp/image2.v
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""
echo ===============================================================================
echo "3.3.1: Quantitation is preserved after conversion from"
echo "       ECAT 6.3 to Analyze and back"
echo "Tested already in 2.3.4"
echo ===============================================================================
echo "3.3.2: Quantitation is preserved after conversion from"
echo "       ECAT 7 to Analyze and back"
echo "Tested already in 2.3.2 and 2.3.3"
echo ===============================================================================
echo "3.4.1: Compatibility with previous a-lot-used software version"
rm temp/* temp2/* 2> nul
rmdir temp temp2 2> nul
$PROGRAM -o=temp -sif ecat6.img ecat7.v
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
# echo passed.;
# cti2sif ecat7.v temp/ecat7.sif
# if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
# echo passed.;
#cti2sif ecat6.img temp/ecat6.sif
#if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""

echo "Check Analyze headers"
if [ -f ecat6.txt ] ; then rm ecat6.txt ; fi
if [ -f ecat7.txt ] ; then rm ecat7.txt ; fi
ana_lhdr temp/ecat6 > ecat6.txt
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
ana_lhdr temp/ecat7 > ecat7.txt
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
iftisval_1_0_4 ecat7.txt "header_image_dimension.dim" "4 256 256 4 3 0 0 0"
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.;
iftisval_1_0_4 ecat7.txt "header_image_dimension.datatype" "4"
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.;
iftisval_1_0_4 ecat6.txt "header_image_dimension.dim" "4 128 128 6 1 0 0 0"
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.;
iftisval_1_0_4 ecat6.txt "header_image_dimension.pixdim" "0 2.34375 2.34375 4.25 0 0 0 0"
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""

echo "Check after converting back to ECAT"
ana2ecat -6 temp/ecat6 temp2
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.;
ana2ecat -7 temp/ecat7 temp2
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.;
ana2ecat -6 prev_ecat6 temp2
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.;
ana2ecat -7 prev_ecat7 temp2
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.;
imgmatch -roughly temp2/ecat6.img temp2/prev_ecat6.img
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""
imgmatch -roughly temp2/ecat7.v temp2/prev_ecat7.v
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""
echo ===============================================================================

if [ 0 -eq 1 ]; then
echo ===============================================================================
echo ""
echo ===============================================================================
echo "3.5.1: Validity of separate frames: can be converted back"
rm temp/* temp2/* 2> nul
rmdir temp temp2 2> nul

$PROGRAM -frames -o=temp -sif ecat7.v
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
# echo passed.;
# cti2sif ecat7.v temp/ecat7.sif
# if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""

ana2ecat -7 temp temp2
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""
ecatcat temp2/ecat7_fr???.v temp2/ecat7.v
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed.;

eframe ecat7.v temp2/ecat7.fra
eframe temp2/ecat7.v temp2/ecat7.fra
cp ecat7.v temp2/temp.v
efixplnr -frames=y temp2/temp.v

imgmatch -roughly temp2/ecat7.v temp2/temp.v
if [ $? -ne 0 ] ; then echo Failed! ; exit 1 ; fi
echo passed. ; echo ""
echo ===============================================================================
fi

#exit 0
echo ""
echo ===============================================================================
echo ""
echo "All passed!"
echo ""
echo ===============================================================================
exit 0
