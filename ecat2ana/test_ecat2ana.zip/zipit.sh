#!/bin/sh
PROGRAM=ecat2ana;
ZIPFILE=test_$PROGRAM.zip
echo "Making "$ZIPFILE;
if [ -f $ZIPFILE ]; then rm $ZIPFILE; fi
zip -D $ZIPFILE *.sh image?.dat image?.inf image?.fra
zip -D $ZIPFILE ecat6.img ecat7.v prev_*.*

